const dbURL="mongodb+srv://test_1:test@cluster0-2uomf.mongodb.net/test?retryWrites=true&w=majority";

module.exports=dbURL;